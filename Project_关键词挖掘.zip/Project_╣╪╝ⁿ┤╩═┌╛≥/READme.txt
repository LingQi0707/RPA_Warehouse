卖家精灵地址： https://www.sellersprite.com/

文件结构：
	I
	I
	I
	I---->Project_分类文件下载and上传
		--->Log.xlsx	
		--->关键词.xlsx
		--->READme.txt
		--->Error_Images
		       --->........
		--->挖掘报告
		       --->........

PS: 
	1、请在使用前，手动输入账号密码登录一次卖家精灵

	2、手动登录时请勾选：  自动登录复选框


使用说明：
	1、将  Project_关键词挖掘.zip  解压到所需位置

	2、打开：关键词.xlsx     将需要挖掘的关键词填入A列     其余列清空保持为空列

	3、打开影刀RPA项目：Project_关键词挖掘

	4、在项目界面右下方配置文件路径：

	            双击可打开各个变量进行修改：

		   例：
		       path_关键词:   			D:\RPA_Data\Project_关键词挖掘\关键词.xlsx

		       path_Error_Images:   		D:\RPA_Data\Project_关键词挖掘\Error_Images\

		       path_Log:  			‪D:\RPA_Data\Project_关键词挖掘\Log.xlsx

		       path_挖掘报告: ‪			‪D:\RPA_Data\Project_关键词挖掘\挖掘报告\
	
	5、进入Edge浏览器设置界面，点击下载菜单项，打开选项：   在下载之前询问每个文件的保存位置

	6、使用Edge浏览器打开卖家精灵官网

	7、运行影刀程序